# Stage 1 content review

Prepared 16 September 2026 for the ASCII workspace build. The original designer handoff and design agreement were read only. Those PDFs are not in this repository.

## What the source material supports

- Designer handoff PDF (10 pages): Livi Cracknell / Livicee identity; professional focus on content operations, CMS, DAM and digital platforms; a second DJ dataset; the content model, evidence types and connected journeys.
- Design agreement PDF (2 pages): Livi Cracknell and LC Sound Consulting; one site with two modes; project files and a launch walkthrough as handover. Final copy and photography are not supplied by the agreement.
- The original build brief: the supplied contact address `livicracknell91@gmail.com`, terminology and the material still expected from the client.
- The inspected source material also included rough design images, persona GIF studies and bug clips. It contains no supplied project case studies, CV, client-approved evidence, named platform experience, tracklists or playable recordings.

These files do not support completed project claims, measured improvements, job seniority, employment dates, actual performance locations or named brand engagements. The earlier sample figures (40% search improvement and 12,000 assets) and invented role chronology have been removed from the content data.

## Implemented collection

The review contains **10 professional projects, 12 attached evidence records, 3 experience groupings (now on the Experience tab) and 5 tracks: 30 records total**. Project, evidence and track IDs remain valid. Retired category URLs redirect to the appropriate Work collection; old Experience URLs redirect to About. Every record is marked `sample: true`; all unconfirmed dates read `To confirm`. No audio source or metric is fabricated. Living copy is `src/content/*.json`, now edited directly in GitHub (see README.md); the local editor described at the time has been retired. Records stay `"sample": true` until Livi confirms them.

Each professional project has one descriptive title, an immediately available summary, one concise proposed-contribution block, compact deliverables and links to usable evidence. Page and record copy is written as a plausible specialist and DJ voice for this review. It is still sample. It is not a confirmed bio, client case or setlist. Evidence is authored for this review, not portrayed as a sanitised version of an unknown real client document.

| Project | Distinct purpose | Inspectable example |
| --- | --- | --- |
| Asset library migration | Move files and their metadata into a managed library | Metadata schema, migration checkpoints, ownership matrix |
| Reusable content model | Maintain shared information through references | Content schema |
| Editorial request to release | Make publishing ownership and review decisions clear | Workflow and contributor starter guide |
| Shared vocabulary | Manage naming and decisions across teams | Governance matrix |
| Content inventory & decisions | Give each audited item a reasoned disposition | Audit decision register |
| Asset rights & reuse | Expose usage information and unanswered permission questions | Usage check matrix |
| CMS authoring experience | Organise the editor’s form around their task | Field guide and acceptance checks |
| Publishing readiness | Review a connected visitor journey before release | Release checklist |
| Team knowledge handover | Make recurring maintenance tasks transferable | Handover index |
| Review & retirement | Maintain and deliberately archive content after launch | Lifecycle workflow |

The five track slots are After hours, Open air, Night shift, Soft focus and First light. Their titles, styles and listening directions are explicitly provisional. Each has a useful detail record and a truthful missing-recording state. Events and location collections have been removed from this presentation.

Experience records are practice-area groupings pending the actual CV. They no longer claim a lead/specialist title or an employment period. No product expertise is inferred from the site technology or reference websites. Capabilities and platforms are not separate public collections.

## Client review items

These are factual input gaps, not reasons to leave independent navigation, layout or presentation work unfinished.

1. **Ten real projects:** confirm titles, context, Livi’s individual contribution, dates, permission to name the organisation, and which current review examples correspond to actual work. Replace or merge examples where the real portfolio differs.
2. **Evidence:** supply approved screenshots, models, workflows or documents and any redaction requirements. Confirm whether any reconstructed example represents her work before changing its label.
3. **Experience:** exact role titles, organisations, dates and linked projects. Add outcome claims only when their wording and supporting source are confirmed.
4. **Five tracks or mixes:** final format, title, audio/embed source, cover permission, credits, duration and release date. Audio remains unavailable until an actual source is supplied.
5. **Profile and artwork:** approve the first-person professional introduction, Livicee description, portrait likeness, hair and tattoo details. An attractive image is not evidence of approved likeness.
6. **Contact:** reconfirm the supplied inbox for both professional enquiries and bookings; add other channels only when supplied.

## Release handling

Stage 1 is intended to deliver a complete navigable review presentation with clearly disclosed sample content. It must not imply that final client copy or recordings have been received. Before a public launch, review each record, replace examples with confirmed material, and remove the sample flag only from records whose facts and assets have been approved.

No content fields simulate publishing, playback or an administrative approval action. Review labels describe content provenance; they are not CMS publishing controls.

## Verification notes

The contract suite (33 checks at the time of this review) validated exact 10/5 Work scope, resolved remaining relationships, evidence dimensions, one contribution block per project, visible sample labels, unconfirmed dates and no fabricated metrics or audio. It also verifies retired-category redirects, four-section navigation and track Style filtering.
