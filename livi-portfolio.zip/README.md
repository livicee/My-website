# Livi Cracknell / Livicee

[Find your website address](../../settings/pages) · [Check publishing in Actions](../../actions)

This page explains how to change the words, links and files on your website. You only need a web browser and your GitHub account. You can't break the live site: if something goes wrong, the previous version stays up until you fix it.

## Before you start

Bookmark these four pages so you can always find your way back:

1. **This page**, the home page of your website's files. GitHub calls this the *repository*.
2. **The content folder**, [src/content](src/content/), where all your text lives.
3. **Actions**, using the second link at the top of this page. It shows whether a change has published.
4. **Your website.** The first link at the top of this page opens **Settings → Pages**; click **Visit site** and bookmark the page that opens.

Sign in to GitHub first; otherwise you won't see the edit buttons.

## A few GitHub words

| GitHub says | It means |
| --- | --- |
| **main** | The live version of your website. Changes saved here are published. |
| **Commit changes** | Save. When you save on **main**, your website updates. |
| **Actions** | The page that shows your website being published: yellow while it works, a green tick when it's done, a red cross if something needs fixing. |
| **History** | Every earlier version of a file, so nothing is ever lost. |
| **JSON** | The format your text files use: labels and text in double quotes, separated by commas. |

## Change some text

1. Open the file you need from the table below.
2. Click the **pencil icon** near the top right of the file (its label is *Edit this file*).
3. Find the words you want to change. Change only the words **inside** the double quotes, and leave the quotes, commas and labels alone.

   Before:

   ```json
   "lede": "For content operations and digital platform enquiries.",
   ```

   After:

   ```json
   "lede": "For content strategy and CMS enquiries.",
   ```

4. Click the green **Commit changes…** button at the top right.
5. In the box that opens, type a short note about what you changed (for example *Update contact text*). Make sure **Commit directly to the main branch** is selected, not *Create a new branch*. Then click **Commit changes**.
6. Open **Actions**. Your change is at the top of the list. Wait about a minute until its yellow dot becomes a **green tick**.
7. Open your website and refresh the page. If you still see the old text, do a full refresh: **Ctrl+Shift+R** on Windows, **Cmd+Shift+R** on a Mac, or pull down to refresh on a phone.

GitHub's *Preview* tab only shows your edit as plain text. To see how it looks, check the website after the green tick.

### Which file to open

| What you want to change | File |
| --- | --- |
| Your names, header status line, email, social links, search-result title and description | [site.json](src/content/site.json) |
| Home, About and Contact page text, CV download | [copy.json](src/content/copy.json) |
| Projects | [projects.json](src/content/projects.json) |
| Experience / CV entries | [experience.json](src/content/experience.json) |
| Mixes and their SoundCloud or Mixcloud links | [mixes.json](src/content/mixes.json) |
| Supporting project evidence | [evidence.json](src/content/evidence.json) |
| The "related projects" heading | [notices.json](src/content/notices.json) |
| Images, recordings or a CV PDF | [media folder](src/content/media/) |

Inside `site.json` and `copy.json`, **production** is your professional side and **sound** is Livicee.

## Upload an image, recording or CV

1. Give the file a simple name with no spaces, for example `cover-january.jpg`.
2. Open the [media folder](src/content/media/), click **Add file** (top right), then **Upload files**.
3. Drag your file in, type a short note, keep **Commit directly to the main branch** selected and click **Commit changes**.
4. Open the JSON file that should use it and type the **filename only**, exactly as spelled, capital letters included. Save it as above and check Actions.

Files must be under 25 MB. Put long mixes on SoundCloud or Mixcloud and paste the link to that set instead. The [editing guide](src/content/README.md#upload-an-image-or-cv) shows exactly where image and CV filenames go.

## If you get a red cross

A red cross means your change wasn't published. **Your website is fine**: the previous version stays up.

1. In **Actions**, click the run with the red cross, then click **build**.
2. Look for the red error line. It tells you which file and which item to fix, for example `src/content/copy.json → production.contact.lede`.
3. The usual cause is a missing or extra double quote or comma near the text you changed. Open that file, fix it and save again.
4. If the message doesn't mention a file in `src/content`, or you can't spot the problem, send the page's link to your web designer, or simply undo your change (below).

## Undo a change

1. Open the file you changed and click **History** (top right, with a clock icon).
2. Click your change in the list. GitHub shows what changed: **red lines** are the old text and **green lines** are your new text.
3. Copy the old words from the red line.
4. Go back to the file, click the **pencil icon**, replace the new words with the old ones and save as usual.
5. Check Actions for the green tick, then refresh your website.

## Sample content

The projects, evidence, Experience entries and mix descriptions currently on the site are **samples** waiting for your real content. Each one has `"sample": true`. Change it to `"sample": false` once that item has been replaced or approved. When everything is real, make the `footerNote` in `site.json` empty (`"footerNote": ""`) to remove the "Sample collection" label. [HANDOVER.md](HANDOVER.md#what-livi-must-replace-or-approve) lists every item.

## More help

- [Editing guide](src/content/README.md): more JSON detail, adding or removing projects and mixes, and recordings. The parts about adding records are best done with help the first few times.
- [Handover notes](HANDOVER.md): ownership, hosting and the list of content to replace.
- [Guide for your AI assistant](AI-ASSISTANT.md): give this file to Claude, ChatGPT or another assistant and it can set up, change and publish the site for you, asking you before anything goes live.
- [Developer setup](DEVELOPER.md): only needed to run the site on a computer. A prompt for setting up your own Claude is in [HANDOVER.md](HANDOVER.md#prompt-for-livis-claude).
